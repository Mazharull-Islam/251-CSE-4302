#ifndef KELVIN_H
#define KELVIN_H
#include <iostream>
using namespace std;
class Farenheit;
class Celsius;

class Kelvin{
    private:
    double temperature;
    public:
    Kelvin(double temp = 273.15);
    void assign(double temp);
    void display()const;
    operator Celsius()const;
    operator Farenheit() const;
    double getTemperature()const;
};
#endif