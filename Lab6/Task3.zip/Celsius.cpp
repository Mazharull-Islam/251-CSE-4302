#include "Celsius.h"
#include "Farenheit.h"
#include "Kelvin.h"
using namespace std;

Celsius::Celsius(double temp) : temperature(temp >= -273.15 ? temp : -273.15) {}

void Celsius::assign(double temp)
{
    temperature = temp >= -273.15 ? temp : -273.15;
}

void Celsius::display() const
{
    cout << "The temperature is " << temperature << " Celsius." << endl;

}

Celsius::operator Farenheit() const
{
    return Farenheit(temperature*(9.0/5.0)+32);
}

Celsius::operator Kelvin() const
{
    return Kelvin(temperature+273.15);
}

double Celsius::getTemperature() const
{
    return temperature ;
}
