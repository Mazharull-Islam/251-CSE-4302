#include "Farenheit.h"
#include "Celsius.h"
#include "Kelvin.h"

Farenheit::Farenheit(double temp) : temperature(temp >= -459.67 ? temp : -459.67) {}

void Farenheit::assign(double temp)
{
    temperature = temp >= -459.67 ? temp : -459.67;
}

void Farenheit::display() const
{
    cout << "The temperature is " << temperature << " Fahrenheit." << endl;
}

Farenheit::operator Celsius() const
{
    return Celsius((temperature-32)*(5.0/9.0));
}

Farenheit::operator Kelvin() const
{
    return Kelvin((temperature - 32) * 5.0 / 9.0 + 273.15);
}

double Farenheit::getTemperature() const
{
    return temperature;
}
