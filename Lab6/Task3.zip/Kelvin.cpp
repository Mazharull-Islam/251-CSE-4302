#include "Kelvin.h"
#include "Celsius.h"
#include "Farenheit.h"

Kelvin::Kelvin(double temp) : temperature(temp >= 0.0? temp : 0.0) {}

void Kelvin::assign(double temp)
{
    temperature = temp >= 0.0? temp : 0.0;
}

void Kelvin::display() const
{
    cout << "The temperature is " << temperature << " Kelvin." << endl;
}

Kelvin::operator Celsius() const
{
    return Celsius(temperature-273.15);
}

Kelvin::operator Farenheit() const
{
    return Farenheit((temperature - 273.15) * 9.0 / 5.0 + 32);
}

double Kelvin::getTemperature() const
{
    return temperature;
}
