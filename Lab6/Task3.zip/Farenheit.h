#ifndef FARENHEIT_H
#define FARENHEIT_H
#include <iostream>
using namespace std;
class Celsius;
class Kelvin;

class Farenheit{
    private:
    double temperature;
    public:
    Farenheit(double temp = 32.0);
    void assign(double temp);
    void display()const;
    operator Celsius()const;
    operator Kelvin() const;
    double getTemperature()const;
};
#endif