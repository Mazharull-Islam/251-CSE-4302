#include <iostream>
#include "Celsius.h"
#include "Farenheit.h"
#include "Kelvin.h"
using namespace std;

int main() {
    Celsius c1(25.0);
    c1.display();

    Farenheit f1 = c1;
    f1.display();

    Kelvin k1 = c1;
    k1.display();

    Farenheit f2(98.6); 
    f2.display();

    Celsius c2 = f2;
    c2.display();

    Kelvin k2 = f2;
    k2.display();

    Kelvin k3(300); 
    k3.display();

    Celsius c3 = k3;
    c3.display();

    Farenheit f3 = k3;
    f3.display();

    return 0;
}
