#ifndef CELSIUS_H
#define CELSIUS_H

#include <iostream>
using namespace std;

class Farenheit;
class Kelvin;

class Celsius{
    private:
    double temperature;
    public:
    Celsius(double temp = 0);
    void assign(double temp);
    void display()const;
    operator Farenheit()const;
    operator Kelvin() const;
    double getTemperature()const;
};
#endif